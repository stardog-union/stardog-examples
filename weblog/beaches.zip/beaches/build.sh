#! /bin/bash

# These commands will create and populate the beaches data


# stardog-admin server start # uncomment this line if the server is not running

stardog-admin db drop beachesDB # in case it already exists
stardog-admin db create -n beachesDB

# Import the CSV files

stardog-admin virtual import beachesDB beaches.sms beaches_data.csv 
stardog-admin virtual import beachesDB weather_06.sms en_climate_hourly_ON_6158359_06-2011_P1H.csv
stardog-admin virtual import beachesDB weather_07.sms en_climate_hourly_ON_6158359_07-2011_P1H.csv
stardog-admin virtual import beachesDB weather_08.sms en_climate_hourly_ON_6158359_08-2011_P1H.csv
stardog-admin virtual import beachesDB weather_09.sms en_climate_hourly_ON_6158359_09-2011_P1H.csv
stardog-admin virtual import beachesDB dates.sms dates.csv 

echo "Smoke test"

stardog query beachesDB "select (count(*) as ?n) {?s ?p ?o .}"

